#include <stdio.h>
#include <stdlib.h>
#include "input.h"

int main() {

    // TODO: implement menu and call subprograms for each operation

    printf("I'm missing a menu! :( \n");

    return EXIT_SUCCESS;
}

